﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.IO;

namespace DialogBoxProject
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        //Menu File part
        bool needsToBeSaved;

        private void fileOpen_Click(object sender, RoutedEventArgs e)
        {
            OpenDocument();
        }
      
        private void fileSave_Click(object sender, RoutedEventArgs e)
        {
            SaveDocument();
        }
        
        private void filePrint_Click(object sender, RoutedEventArgs e)
        {
            PrintDocument();
        }
    
        private void fileExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        void OpenDocument()
        {
            OpenFileDialog dlg = new OpenFileDialog();
            ////dlg.ShowDialog();
            dlg.FileName = "Document"; // Default file name
            dlg.DefaultExt = ".txt"; // Default file extension
            dlg.Filter = "Text documents (.txt)|*.txt"; // Filter files by extension

            Nullable<bool> result = dlg.ShowDialog();
            if (result == true)
            {
                //UTF8Encoding utf8 = new UTF8Encoding();
                string filename = dlg.FileName;
                this.documentTextBox.Text = File.ReadAllText(filename);//File类的ReadAllText()方法可以读取文件。
                //this.documentTextBox.Text = File.ReadAllText(filename, utf8);

            }
        }
        void SaveDocument()
        {
            SaveFileDialog dlg = new SaveFileDialog();

            dlg.FileName = "Document";
            dlg.DefaultExt = ".txt";
            dlg.Filter = "Text document (.txt)|*.txt";

            Nullable<bool> result = dlg.ShowDialog();

            if (result == true)
            {
                string fileName = dlg.FileName;
                //MessageBox.Show(fileName);
                File.WriteAllText(fileName,documentTextBox.Text);//File类的writeAllText()方法可以写文件。
            }
        }
        void PrintDocument()
        {
            PrintDialog dlg = new PrintDialog();

            dlg.PageRangeSelection = PageRangeSelection.AllPages;
            dlg.UserPageRangeEnabled = true;

            Nullable<bool> result = dlg.ShowDialog();

            if (result == true)
            {
            }
        }

        private void documentTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            this.needsToBeSaved = true;
        }

        private void mainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (needsToBeSaved)
            {
                string messageBoxText = "This document needs to be saved. Click Yes to save and exit, No to exit without saving, or Cancel to not exit.";
                string caption = "word processor";
                MessageBoxButton button = MessageBoxButton.YesNoCancel;
                MessageBoxImage icon = MessageBoxImage.Warning;
                MessageBoxResult result = MessageBox.Show(messageBoxText,caption,button,icon);

                switch (result)
                {
                    case MessageBoxResult.Yes:
                        SaveDocument();
                        break;
                    case MessageBoxResult.No:
                        break;
                    case MessageBoxResult.Cancel:
                        e.Cancel = true;
                        break;
                }
            }
        }

        //Menu Edit Part
        private void editFindMenuItem_Click(object sender, RoutedEventArgs e)
        {

        }

        //Menu Format Part
        private void formatFontMenuItem_Click(object sender, RoutedEventArgs e)
        {
            FontDialogBox dlg = new FontDialogBox();
            dlg.FontFamily = documentTextBox.FontFamily;
            dlg.FontStyle = documentTextBox.FontStyle;
            dlg.FontWeight = documentTextBox.FontWeight;
            dlg.FontSize = documentTextBox.FontSize;
            dlg.ShowDialog();

            if (dlg.DialogResult == true)
            {
                documentTextBox.FontFamily = dlg.FontFamily;
                documentTextBox.FontStyle = dlg.FontStyle;
                documentTextBox.FontWeight = dlg.FontWeight;
                documentTextBox.FontSize = dlg.FontSize;
            }
        }

        private void formatMarginsMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MarginsDialogBox dlg = new MarginsDialogBox();
            dlg.Owner = this;
            dlg.DocumentMargin = documentTextBox.Margin;
            dlg.ShowDialog();

            if (dlg.DialogResult == true)
            {
                documentTextBox.Margin = dlg.DocumentMargin;
            }
        }          

    }
}
