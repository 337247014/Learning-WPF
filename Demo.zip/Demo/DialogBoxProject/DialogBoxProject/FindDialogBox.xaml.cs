﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Text.RegularExpressions;

namespace DialogBoxProject
{
    /// <summary>
    /// Interaction logic for FindDialogBox.xaml
    /// </summary>
    public partial class FindDialogBox : Window
    {
        public FindDialogBox()
        {
            InitializeComponent();
        }

        int index=0;
        int length=0;
        int matchIndex=0;
        MatchCollection matchs;
        TextBox textBoxToSearch;

        public int Index
        {
            get { return this.index; }
            set { this.index = value; }
        }
        public int Lenght
        {
            get { return length; }
            set { this.length = value; }
        }

        private void FindNextButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void FindWhatTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ResetFind();
        }

        private void Criteria_Click(object sender, RoutedEventArgs e)
        {
            ResetFind();
        }     

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        void ResetFind()
        {
            this.FindNextButton.IsEnabled = true;
            matchs = null;
        }

    }
}
