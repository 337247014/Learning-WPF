﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DialogBoxProject
{
    /// <summary>
    /// Interaction logic for FontDialogBox.xaml
    /// </summary>
    public partial class FontDialogBox : Window
    {
        public FontDialogBox()
        {
            InitializeComponent();

            //this.fontListBox.ItemsSource = FontPropertyLists.FontFaces;
            //this.styleListBox.ItemsSource = FontPropertyLists.FontStyles;
            //this.weightListBox.ItemsSource = FontPropertyLists.FontWeights;
            //this.sizeListBox.ItemsSource = FontPropertyLists.FontSizes;
        }

        public new FontFamily FontFamily
        {
            get { return (FontFamily)this.fontListBox.SelectedItem; }
            set
            {
                this.fontListBox.SelectedItem = value;
            }
        }
        public new FontStyle FontStyle
        {
            get { return (FontStyle)this.styleListBox.SelectedItem; }
            set
            {
                this.styleListBox.SelectedItem = value;
            }
        }
        public new FontWeight FontWeight
        {
            get { return (FontWeight)this.weightListBox.SelectedItem; }
            set
            {
                this.weightListBox.SelectedItem = value;
            }
        }
        public new double FontSize
        {
            get { return (double)this.sizeListBox.SelectedItem; }
            set
            {
                this.sizeListBox.SelectedItem = value;
            }
        }

        private void okButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }
    }
}
