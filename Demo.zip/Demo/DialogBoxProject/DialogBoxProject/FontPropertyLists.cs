﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Windows.Media;
using System.Windows;

namespace DialogBoxProject
{
    class FontPropertyLists
    {
        static Collection<FontFamily> fontFaces;
        static Collection<FontStyle> fontStyles;
        static Collection<FontWeight> fontWeights;
        static Collection<double> fontSizes;

        public static ICollection<FontFamily> FontFaces
        {
            get
            {
                if (fontFaces == null)
                {
                    fontFaces = new Collection<FontFamily>();
                }
                foreach (FontFamily fontFamily in Fonts.SystemFontFamilies)
                {
                    fontFaces.Add(fontFamily);
                }
                return fontFaces;
            }
        }

        public static ICollection<FontStyle> FontStyles
        {
            get
            {
                if (fontStyles == null)
                {
                    fontStyles = new Collection<FontStyle>();
                    fontStyles.Add(System.Windows.FontStyles.Oblique);
                    fontStyles.Add(System.Windows.FontStyles.Normal);
                    fontStyles.Add(System.Windows.FontStyles.Italic);
                }
                return fontStyles;
            }
        }

        public static ICollection<FontWeight> FontWeights
        {
            get
            {
                if (fontWeights == null)
                {
                    fontWeights = new Collection<FontWeight>();
                    fontWeights.Add(System.Windows.FontWeights.Thin);
                    fontWeights.Add(System.Windows.FontWeights.Light);
                    fontWeights.Add(System.Windows.FontWeights.Normal);
                    fontWeights.Add(System.Windows.FontWeights.Medium);
                    fontWeights.Add(System.Windows.FontWeights.Heavy);
                    fontWeights.Add(System.Windows.FontWeights.SemiBold);
                    fontWeights.Add(System.Windows.FontWeights.Bold);
                    fontWeights.Add(System.Windows.FontWeights.ExtraLight);
                    fontWeights.Add(System.Windows.FontWeights.ExtraBold);
                    fontWeights.Add(System.Windows.FontWeights.ExtraBlack);
                }
                //foreach (FontWeight fon in FontWeights)
                //{
                //    fontWeights.Add(fon);
                //}
                return fontWeights;
            }
        }

        public static ICollection<double> FontSizes
        {
            get
            {
                if (fontSizes == null)
                {
                    fontSizes = new Collection<double>();
                }
                for (double i = 2; i < 40; i++ )
                {
                    fontSizes.Add(i);
                }
                return fontSizes;
            }
        }
    }
}
