﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections.ObjectModel;

namespace StyleIntroductionProject
{
    class PhotoList:ObservableCollection<Photo>
    {
        DirectoryInfo directory;

        //public DirectoryInfo Directory
        //{
        //    get { return directory; }
        //    set
        //    {
        //        this.directory = value;
        //        Update();
        //    }
        //}
        public string Path
        {
            get { return this.directory.FullName; }
            set
            {
                this.directory = new DirectoryInfo(value);
                Update();
            }
        }

        //public PhotoList() { }
        //public PhotoList(string path) : this(new DirectoryInfo(path)) { }
        //public PhotoList(DirectoryInfo directory)
        //{
        //    this.directory = directory;
        //    Update();
        //}

        private void Update()
        {
            foreach (FileInfo f in directory.GetFiles("*.jpg"))
            {
                Add(new Photo(f.FullName));
            }
        }
    }
}
