﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StyleIntroductionProject
{
    class Photo
    {
        private string source;

        public Photo(string source)
        {
            this.source = source;
        }

        public string Source
        {
            get { return source; }
            set { this.source = value;}
        }

        public override string ToString()
        {
            return this.source;
        }
    }
}
