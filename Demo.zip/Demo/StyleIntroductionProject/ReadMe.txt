﻿DirectoryInfy类：（公开用于创建、移动和枚举目录和子目录的实例方法。 此类不能被继承。）
1.构造函数 
DirectoryInfo（string Path） path是System.String 表示一个字符串，它指定要在其中创建 DirectoryInfo 的路径（文件路径）。 
2.属性
FullName: 用于获取目录或文件的完整目录。 
Parent:用于获取指定子目录的父目录。
3.方法
GetFiles():返回当前目录的文件列表。
GetFiles(string):返回当前目录中与给定的搜索模式匹配的文件列表。如GetFiles("*.jsp");其中*表示多个字符，？表示一个字符

