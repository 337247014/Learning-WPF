﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;

namespace SimpleDataBing.ValidationRuleUtil
{
	public class NumberRangeRule:ValidationRule
	{
		int min;
		public int Min
		{
			get { return min; }
			set
			{
				if (min != value) {
					min = value;
				}
			}
		}

		int max;
		public int Max
		{
			get { return min; }
			set
			{
				if (max != value) {
					max = value;
				}
			}
		}

		public override ValidationResult Validate(object value, System.Globalization.CultureInfo cultureInfo)
		{
			int number;
			if (!int.TryParse((string)value, out number)) {
				return new ValidationResult(false, "Invalid number format");
			}

			if (number < min || number > max) {
				return new ValidationResult(false,string.Format("Number out of range ({0} - {1})",min,max));
			}

			return new ValidationResult(true, null);
		}
	}
}
