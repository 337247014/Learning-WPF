﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using System.Windows.Media;

namespace SimpleDataBing.Converter
{
	public class AgeToForegroundConverter:IValueConverter
	{
		/// <summary>
		/// 将数据源的数值转换成用户界面的目的类型时调用
		/// value:绑定源生成的值
		/// targetType:绑定目标属性的类型
		/// parameter:要使用的转换器参数
		/// culture:要用在转化器中的区域性
		/// </summary>
		/// <param name="value"></param>
		/// <param name="targetType"></param>
		/// <param name="parameter"></param>
		/// <param name="culture"></param>
		/// <returns></returns>
		public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
			if (targetType != typeof(Brush)) { return null; }

			int age = int.Parse(value.ToString());
			return (age >= 60 ? Brushes.Red : Brushes.Black);
		}

		/// <summary>
		/// 将界面数值转换成数据源的类型时进行调用
		/// value:绑定目标生成的值
		/// targetType:要转换到得类型（数据源类型）
		/// parameter:要使用的转化器参数
		/// culture:要用在转化器中的区域性
		/// </summary>
		/// <param name="value"></param>
		/// <param name="targetType"></param>
		/// <param name="parameter"></param>
		/// <param name="culture"></param>
		/// <returns></returns>
		public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
			throw new NotImplementedException();
		}  
	}
}
