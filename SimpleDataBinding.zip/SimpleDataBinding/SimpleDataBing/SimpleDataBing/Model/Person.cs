﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SimpleDataBing.Util;

namespace SimpleDataBing.Model
{
	public class Person : NotifyPropertyChangedImplemeter
	{
		string name;
		public string Name
		{
			get { return this.name; }
			set
			{
				if (this.name != value) {
					this.name = value;
					OnPropertyChanged("Name");
				}
			}
		}

		int age;
		public int Age
		{
			get { return this.age; }
			set
			{
				if (this.age != value) {
					this.age = value;
					OnPropertyChanged("Age");
				}
			}
		}

		public Person() { }
		public Person(string name, int age)
		{
			this.name = name;
			this.age = age;
		}
	}
}
