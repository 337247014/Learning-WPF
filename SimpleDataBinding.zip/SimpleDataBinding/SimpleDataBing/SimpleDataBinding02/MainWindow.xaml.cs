﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SimpleDataBinding02.Model;

namespace SimpleDataBinding02
{
	/// <summary>
	/// MainWindow.xaml の相互作用ロジック
	/// </summary>
	public partial class MainWindow : Window
	{
		Person person = new Person("Jack", 18);

		public MainWindow()
		{
			InitializeComponent();

			grid.DataContext = person;

			this.btnBirthday.Click += btnBirthday_Click;
		}

		private void btnBirthday_Click(object sender, RoutedEventArgs e)
		{
			++person.Age;
			MessageBox.Show(String.Format("Happy Birthday,{0},age {1}", person.Name, person.Age), "Birthday");
		}
	}
}
