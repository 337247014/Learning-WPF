﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SimpleDataBing01.Model
{
	public class Person
	{
		string name;
		public string Name
		{
			get { return this.name; }
			set
			{
				if (this.name != value) {
					this.name = value;
				}
			}
		}

		int age;
		public int Age
		{
			get { return this.age; }
			set
			{
				if (this.age != value) {
					this.age = value;
				}
			}
		}

		public Person() { }
		public Person(string name, int age)
		{
			this.name = name;
			this.age = age;
		}
	}
}
