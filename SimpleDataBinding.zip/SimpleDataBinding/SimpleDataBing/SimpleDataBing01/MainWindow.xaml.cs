﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SimpleDataBing01.Model;

namespace SimpleDataBing01
{
	/// <summary>
	/// MainWindow.xaml の相互作用ロジック
	/// </summary>
	public partial class MainWindow : Window
	{
		Person person = new Person("Jack",18);

		public MainWindow()
		{
			InitializeComponent();

			this.txtName.Text = person.Name;
			this.txtAge.Text = person.Age.ToString();

			this.btnBirthday.Click += btnBirthday_Click;
		}

		private void btnBirthday_Click(object sender, RoutedEventArgs e)
		{
			//手动更新person类对象
			person.Name = this.txtName.Text;
			person.Age = Convert.ToInt32(this.txtAge.Text);

			//进行相应的数据逻辑处理
			++person.Age;

			//手动更新界面
			this.txtAge.Text = person.Age.ToString();

			MessageBox.Show(String.Format("Happy Birthday,{0},age {1}", person.Name, person.Age), "Birthday");
		}
	}
}
