﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace WPF_MVVM_Learning.Util
{
    public class NotifyPropertyChangedImplementer:INotifyPropertyChanged
	{
		public event PropertyChangedEventHandler PropertyChanged;

		protected void OnPropertyChanged(string propertyName)
		{
			PropertyChangedEventHandler handler = this.PropertyChanged;
			if (handler != null) {
				handler(this,new PropertyChangedEventArgs(propertyName));
			}
		}
	}
}
