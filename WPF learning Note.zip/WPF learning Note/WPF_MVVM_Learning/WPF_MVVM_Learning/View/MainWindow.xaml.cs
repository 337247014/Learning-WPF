﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WPF_MVVM_Learning.ViewModel;
using WPF_MVVM_Learning.Model;

namespace WPF_MVVM_Learning
{
	/// <summary>
	/// MainWindow.xaml の相互作用ロジック
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainViewModel viewModel = new MainViewModel();
		//public StaffEntity MyStaff = new StaffEntity();

		public MainWindow()
		{
			InitializeComponent();

			viewModel.Init();

			//this.sp.DataContext = MyStaff;
			//this.grid.DataContext = MyStaff;
			this.sp.DataContext = viewModel.MyStaff;
			this.grid.DataContext = viewModel.MyStaff;
			this.DataContext = viewModel;
		}

		private void StaffDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			Staff entity = this.StaffDataGrid.SelectedItem as Staff;
			if (entity != null) {
				//MyStaff.MyStaffID = entity.StaffID;
				//MyStaff.MyStaffName = entity.StaffName;
				//MyStaff.Sex = Convert.ToInt32(entity.Sex);
				//MyStaff.Age = Convert.ToInt32(entity.Age);
				//MyStaff.HireTime = Convert.ToDateTime(entity.HireDate);
				//MyStaff.Email = entity.Email;
			    viewModel.MyStaff.MyStaffID = entity.StaffID;
				viewModel.MyStaff.MyStaffName = entity.StaffName;
				viewModel.MyStaff.Sex = Convert.ToInt32(entity.Sex);
				viewModel.MyStaff.Age = Convert.ToInt32(entity.Age);
				viewModel.MyStaff.HireTime = Convert.ToDateTime(entity.HireDate);
				viewModel.MyStaff.Email = entity.Email;
			}
		}

		private void txtStaffID_PreviewLostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
		{
			viewModel.MyStaff.MyStaffID = txtStaffID.Text;
			if (viewModel.AvairableStaffID()) {
				txtstaffName.Text = String.Empty;
				rbtFemale.IsChecked = false;
				rbtMale.IsChecked = false;
				txtAge.Text = String.Empty;
				dpHireDate.Text = String.Empty;
				txtEmail.Text = String.Empty;
			}
		}
	}
}
