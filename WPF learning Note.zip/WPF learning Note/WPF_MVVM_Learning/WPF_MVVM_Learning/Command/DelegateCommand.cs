﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace WPF_MVVM_Learning.Command
{
	public class DelegateCommand:ICommand
	{
		private readonly Action myExecuteMethod = null;

		public DelegateCommand(Action executeMethod)
		{
			myExecuteMethod = executeMethod;
		}

		public void Execute()
		{
			if (myExecuteMethod != null) {
				myExecuteMethod();
			}
		}

		public void Execute(object parameter)
		{
			Execute();
		}

		public bool CanExecute()
		{
			return true;
		}

		public bool CanExecute(object parameter)
		{
			return CanExecute();
		}

		public event EventHandler CanExecuteChanged
		{
			add { CommandManager.RequerySuggested += value; }
			remove { CommandManager.RequerySuggested -= value; }
		}
	}
}
