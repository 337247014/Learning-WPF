﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace WPF_MVVM_Learning.Converter
{
	public class SexConverter:IValueConverter
	{
		/// <summary>
		/// 将数据源的数值转换成用户界面的目的类型时调用
		/// value:绑定源生成的值
		/// targetType:绑定目标属性的类型
		/// parameter:要使用的转换器参数
		/// culture:要用在转化器中的区域性
		/// </summary>
		/// <param name="value"></param>
		/// <param name="targetType"></param>
		/// <param name="parameter"></param>
		/// <param name="culture"></param>
		/// <returns></returns>
		public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
			try {
				Int32 s = (Int32)value;
				//ConverterParameter: 0-Female, 1-Male
				if (s == int.Parse(parameter.ToString())) {
					return true;
				} else {
					return false;
				}
			} catch (Exception) {
				return false;
			}

		}

		/// <summary>
		/// 将界面数值转换成数据源的类型时进行调用
		/// value:绑定目标生成的值
		/// targetType:要转换到得类型（数据源类型）
		/// parameter:要使用的转化器参数
		/// culture:要用在转化器中的区域性
		/// </summary>
		/// <param name="value"></param>
		/// <param name="targetType"></param>
		/// <param name="parameter"></param>
		/// <param name="culture"></param>
		/// <returns></returns>
		public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
			bool check = (bool)value;
			if (check == true) {
				return parameter;
			} else if (check == false && (string)parameter == "1") {
				return 0;
			} else if (check == false && (string)parameter == "0") {
				return 1;
			} else {
				return -1;
			}
		}  
	}
}
