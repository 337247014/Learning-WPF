﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WPF_MVVM_Learning.Util;
using System.Collections.ObjectModel;
using WPF_MVVM_Learning.Model;
using WPF_MVVM_Learning.Command;
using System.Windows.Input;
using System.Windows;
using System.ComponentModel;
using System.Windows.Data;

namespace WPF_MVVM_Learning.ViewModel
{
	public class MainViewModel:NotifyPropertyChangedImplementer
	{
		private ObservableCollection<Staff> myStaffList;
		public ObservableCollection<Staff> MyStaffList
		{
			get { return myStaffList; }
			set
			{
				if (myStaffList != value) {
					myStaffList = value;
					OnPropertyChanged("MyStaffList");
				}
			}
		}

		private StaffEntity myStaff = new StaffEntity();
		public StaffEntity MyStaff
		{
			get { return myStaff;}
			set
			{
				if (myStaff != value) {
					myStaff = value;
					OnPropertyChanged("MyStaff");
				}
			}
		}

		private int minAge;
		public int MinAge
		{
			get { return minAge; }
			set
			{
				if (minAge != value) {
					minAge = value;
					OnPropertyChanged("MinAge");
				}
			}
		}
		private int maxAge;
		public int MaxAge
		{
			get { return maxAge; }
			set
			{
				if (maxAge != value) {
					maxAge = value;
					OnPropertyChanged("MaxAge");
				}
			}
		}

		private StaffInformationDBEntities staffInfo = new StaffInformationDBEntities();
		private ICollectionView myStaffListView = null;

		public void Init()
		{
			IEnumerable<Staff> staffList = staffInfo.Staffs;
			MyStaffList = new ObservableCollection<Staff>();
			foreach (Staff staff in staffList) {
				MyStaffList.Add(staff);
			}

			myStaffListView = CollectionViewSource.GetDefaultView(MyStaffList);
			myStaffListView.MoveCurrentTo(null);
			//进行排序
			myStaffListView.SortDescriptions.Add(new SortDescription("StaffID", ListSortDirection.Ascending));
			//进行过滤
			//myStaffListView.Filter = delegate(Object item) {
			//    return ((Staff)item).Age >= 18;
			//};
		}

		#region 视图操作
		//过滤
		public ICommand FilterCommand
		{
			get { return new DelegateCommand(AgeFilter); }
		}

		private void AgeFilter()
		{
			myStaffListView.Filter = delegate(Object item) {
				return ((Staff)item).Age >= MinAge && ((Staff)item).Age <= MaxAge;
			};
		}

		//当前项操作
		public ICommand ToFirstCommand
		{
			get { return new DelegateCommand(ToFirst); }
		}
		private void ToFirst()
		{
			myStaffListView.MoveCurrentToFirst();
		}

		public ICommand ToPreviousCommand
		{
			get { return new DelegateCommand(ToPrevious); }
		}
		private void ToPrevious()
		{
			myStaffListView.MoveCurrentToPrevious();
			if (myStaffListView.IsCurrentBeforeFirst) {
				myStaffListView.MoveCurrentToFirst();
			}
		}

		public ICommand ToNextCommand
		{
			get { return new DelegateCommand(ToNext); }
		}
		private void ToNext()
		{
			myStaffListView.MoveCurrentToNext();
			if (myStaffListView.IsCurrentAfterLast) {
				myStaffListView.MoveCurrentToLast();
			}
		}

		public ICommand ToLastCommand
		{
			get { return new DelegateCommand(ToLast); }
		}
		private void ToLast()
		{
			myStaffListView.MoveCurrentToLast();
		}
		#endregion

		#region 插入操作
		public ICommand InsertCommnad
		{
			get { return new DelegateCommand(InsertStaff); }
		}

		private void InsertStaff()
		{
			Staff newStaff = new Staff();
			if (AvairableStaffID()) {
				newStaff.StaffID = MyStaff.MyStaffID;
				newStaff.StaffName = MyStaff.MyStaffName;
				newStaff.Sex = MyStaff.Sex;
				newStaff.Age = MyStaff.Age;
				newStaff.Email = MyStaff.Email;
				newStaff.HireDate = MyStaff.HireTime;
				newStaff.Can = "0";
				newStaff.UpSeq = 0;

				staffInfo.Staffs.AddObject(newStaff);
			} else {
				MessageBox.Show("the Staff ID is not avairable.");
			}

			staffInfo.SaveChanges();

			AddOrUpdateRegisteredElement(newStaff);
			SelectRegisteredElement(newStaff);
			MessageBox.Show("adding a new staff successfully!");
		}
		#endregion

		#region 更新操作
		public ICommand UpdateCommand
		{
			get { return new DelegateCommand(UpdateStaff); }
		}
		private void UpdateStaff()
		{
			if (AvairableStaffID()) { return; }
			Staff current = (Staff)this.myStaffListView.CurrentItem;
			if (current.StaffName != MyStaff.MyStaffName) { current.StaffName = MyStaff.MyStaffName; }
			if (current.Sex != MyStaff.Sex) { current.Sex = MyStaff.Sex; }
			if (current.Age != MyStaff.Age) { current.Age = MyStaff.Age; }
			if (current.HireDate != MyStaff.HireTime) { current.HireDate = MyStaff.HireTime; }
			if (current.Email != myStaff.Email) { current.Email = MyStaff.Email; }

			staffInfo.SaveChanges();

			MessageBox.Show("Update the staff successfully!");
		}
		#endregion

		#region 删除操作
		public ICommand DeleteCommand
		{
			get { return new DelegateCommand(DeleteStaff); }
		}

		private void DeleteStaff()
		{
			Staff current = myStaffListView.CurrentItem as Staff;
			staffInfo.Staffs.DeleteObject(current);
			MyStaffList.Remove(current);
			staffInfo.SaveChanges();
			myStaffListView.MoveCurrentToNext();
			MessageBox.Show("Delete the Staff Successfully!");
		}
		#endregion

		public bool AvairableStaffID()
		{
			Staff current = staffInfo.Staffs.Where(x => x.StaffID == MyStaff.MyStaffID).FirstOrDefault();
			if (current == null) {
				return true;
			} else {
				return false;
			}
		}

		private void AddOrUpdateRegisteredElement(Staff target)
		{
			int index = this.MyStaffList.IndexOf(target);
			if (index == -1) {
				this.MyStaffList.Add(target);
			} else {
				this.MyStaffList[index] = target;
			}
		}

		private void SelectRegisteredElement(Staff target)
		{
			Staff current = (Staff)this.myStaffListView.CurrentItem;
			if (current == null || current.StaffID != target.StaffID) {
				Staff entity = this.MyStaffList.SingleOrDefault(x => x.StaffID == target.StaffID);
				if (entity != null) {
					this.myStaffListView.MoveCurrentTo(entity);
				}
			}
		}
		
	}
}
