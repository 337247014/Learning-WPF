﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WPF_MVVM_Learning.Util;

namespace WPF_MVVM_Learning.Model
{
	public class StaffEntity:NotifyPropertyChangedImplementer
	{
		private string myStaffID;
		public string MyStaffID
		{
			get { return myStaffID; }
			set
			{
				if (myStaffID != value) {
					myStaffID = value;
					OnPropertyChanged("MyStaffID");
				}
			}
		}

		private string myStaffName;
		public string MyStaffName
		{
			get { return myStaffName; }
			set
			{
				if (myStaffName != value) {
					myStaffName = value;
					OnPropertyChanged("MyStaffName");
				}
			}
		}

		private int sex;
		public int Sex
		{
			get { return sex; }
			set
			{
				if (sex != value) {
					sex = value;
					OnPropertyChanged("Sex");
				}
			}
		}

		private int age;
		public int Age
		{
			get { return age; }
			set
			{
				if (age != value) {
					age = value;
					OnPropertyChanged("Age");
				}
			}
		}

		private DateTime hireTime;
		public DateTime HireTime
		{
			get { return hireTime; }
			set
			{
				if (hireTime != value) {
					hireTime = value;
					OnPropertyChanged("HireTime");
				}
			}
		}

		private string email;
		public string Email
		{
			get { return email; }
			set
			{
				if (email != value) {
					email = value;
					OnPropertyChanged("Email");
				}
			}
		}
	}
}
